<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_model extends CI_Model {

	public function registerUser($data)
	{
		return $this->db->insert('user', $data);
	}

	public function tampilUser()
	{
		$sql = $this->db->get('user','name');
		return $sql->row();
	}

}

/* End of file Register_model.php */
/* Location: ./application/models/Register_model.php */