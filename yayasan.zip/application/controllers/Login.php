<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }


	public function index()
	{

		if ($this->session->userdata('email')) {
            redirect(base_url('user'));
        }

        $this->form_validation->set_rules('email', 'E-mail', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
        	$data = [
			'judul' => 'Yayasan Inti Perubahan Bangsa | Login',
			];
			$this->load->view('login', $data);
        	
        } else {
        	$this->_login();
        }

		
	}


	 private function _login()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $user = $this->db->get_where('user', ['email' => $email])->row_array();

        // jika usernya ada
        if ($user) {
            // jika usernya aktif
            if ($user['is_active'] == 1) {
                // cek password
                if (password_verify($password, $user['password'])) {
                    $data = [
                        'email' => $user['email'],
                        'role_id' => $user['role_id']
                    ];
                    var_dump($data);
                    $this->session->set_userdata($data);
                    if ($user['role_id'] == 1) {
                        redirect(base_url('administrator'));
                    } else {
                        redirect(base_url('user'));
                    }
                } else {
                    $this->session->set_flashdata('pesan', '<div class="alert alert-danger text-center" role="alert">Password salah!</div>');
                    redirect(base_url('login'));
                }
            } else {
                $this->session->set_flashdata('pesan', '<div class="alert alert-danger text-center" role="alert">E-mail belum di aktivasi!</div>');
                redirect(base_url('login'));
            }
        } else {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger text-center" role="alert">E-mail belum terdaftar!</div>');
            redirect(base_url('login'));
        }
    }

    public function logout()
    {
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('role_id');

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">You have been logged out!</div>');
        redirect('login');
    }


    public function blocked()
    {
        $this->load->view('login/blocked');
    }


    


}
