<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Administrator extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('Menu_model');
        $this->load->helper('form');
        is_logged_in();
    }
    
	public function index()
	{
		
		$data = [
			'judul' => 'Administrator',
			
		];
			$this->load->view('admin/header', $data);
            $this->load->view('admin/navbar', $data);
            $this->load->view('admin', $data);
            $this->load->view('admin/footer');
	}


	
// ////////////////////////////////////////////////////////////////////////////
	// BLOCK AKSES
// ////////////////////////////////////////////////////////////////////////////
	public function role()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get('user_role')->result_array();

        
       $data = [
			'judul' => 'Administrator | Role',
			'user'	=> $this->Register_model->tampilUser(),
			'admin'	=> 'role'
		];
		$this->load->view('admin/wrapp', $data);
    }

	public function roleAccess($role_id)
    {
        $data['title'] = 'Role Access';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();

        $this->db->where('id !=', 1);
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->load->view('temp/header', $data);
        $this->load->view('temp/navbar', $data);
        $this->load->view('temp/content', $data);
        $this->load->view('role', $data);
        $this->load->view('temp/footer');
    }


    public function changeAccess()
    {
        $menu_id = $this->input->post('menuId');
        $role_id = $this->input->post('roleId');

        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];

        $result = $this->db->get_where('user_access_menu', $data);

        if ($result->num_rows() < 1) {
            $this->db->insert('user_access_menu', $data);
        } else {
            $this->db->delete('user_access_menu', $data);
        }

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Access Changed!</div>');
    }
// ////////////////////////////////////////////////////////////////////////////
// BLOCK KEBAWAH MENU
// ////////////////////////////////////////////////////////////////////////////
	public function menu()
	{

		$data['judul'] = 'Administrator | Menu Management';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->form_validation->set_rules('menu', 'Menu', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('temp/header', $data);
            $this->load->view('temp/navbar', $data);
            $this->load->view('temp/content', $data);
            $this->load->view('tambahmenu', $data);
            $this->load->view('temp/footer');
        } else {
            $this->db->insert('user_menu', ['menu' => $this->input->post('menu')]);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success" role="alert">Menu baru ditambahkan!</div>');
            redirect(base_url('administrator/menu'));
        }
    }

    public function submenu()
    {
    	$data['judul'] = 'Administrator | Submenu Management';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $this->load->model('Menu_model', 'menu');

        $data['subMenu'] = $this->menu->getSubMenu();
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('menu_id', 'Menu', 'required');
        $this->form_validation->set_rules('url', 'URL', 'required');
        $this->form_validation->set_rules('icon', 'icon', 'required');

        if ($this->form_validation->run() ==  false) {
            $this->load->view('temp/header', $data);
            $this->load->view('temp/navbar', $data);
            $this->load->view('temp/content', $data);
            $this->load->view('submenu', $data);
            $this->load->view('temp/footer');
        } else {
            $data = [
                'title' => $this->input->post('title'),
                'menu_id' => $this->input->post('menu_id'),
                'url' => $this->input->post('url'),
                'icon' => $this->input->post('icon'),
                'is_active' => $this->input->post('is_active')
            ];
            $this->db->insert('user_sub_menu', $data);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success text-center" role="alert">Sub menu baru ditambahkan!</div>');
            redirect('administrator/submenu');
        }
    }

// ////////////////////////////////////////////////////////////////////////////
    // BLOCK USERS
// ////////////////////////////////////////////////////////////////////////////
    public function users()
    {
    	$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

    	$data['judul'] = 'Administrator | Users';

    	$this->load->view('temp/header', $data);
        $this->load->view('temp/navbar', $data);
        $this->load->view('temp/content', $data);
        $this->load->view('users', $data);
        $this->load->view('temp/footer');
    }
    

	
}
