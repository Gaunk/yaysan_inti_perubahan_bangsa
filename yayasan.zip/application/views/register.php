
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?= $judul; ?></title>
    <!-- Bootstrap CSS -->

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="<?= base_url('public') ?>/images/favicon-3.png" type="image/png">
    <link rel="manifest" href="<?= base_url('public') ?>/site.webmanifest">
    <link rel="mask-icon" href="<?= base_url('public') ?>/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <link rel="stylesheet" href="<?= base_url('public/admin') ?>/assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="<?= base_url('public/admin') ?>/assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('public/admin') ?>/assets/vendor/fonts/fontawesome/css/fontawesome-all.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="<?= base_url('public') ?>/css/slick.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="<?= base_url('public') ?>/css/animate.css">
    
    <!--====== Nice Select css ======-->
    <link rel="stylesheet" href="<?= base_url('public') ?>/css/nice-select.css">
    
    <!--====== Nice Number css ======-->
    <link rel="stylesheet" href="<?= base_url('public') ?>/css/jquery.nice-number.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="<?= base_url('public') ?>/css/magnific-popup.css">


    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="<?= base_url('public') ?>/css/font-awesome.min.css">
    
    <!--====== Default css ======-->
    <link rel="stylesheet" href="<?= base_url('public') ?>/css/default.css">
    
    <!--====== Style css ======-->
    <link rel="stylesheet" href="<?= base_url('public') ?>/css/style.css">
    <link rel="stylesheet" href="<?= base_url('public/admin') ?>/assets/libs/css/style.css">

    
    <!--====== Responsive css ======-->
    <link rel="stylesheet" href="<?= base_url('public') ?>/css/responsive.css">
    
    <style>
    html,
    body {
        height: 100%;
    }

    body {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
    }
    </style>
</head>
<!-- ============================================================== -->
<!-- signup form  -->
<!-- ============================================================== -->

<body>
    <!--====== PRELOADER PART START ======-->
    
    <div class="preloader">
        <div class="loader rubix-cube">
            <div class="layer layer-1"></div>
            <div class="layer layer-2"></div>
            <div class="layer layer-3 color-1"></div>
            <div class="layer layer-4"></div>
            <div class="layer layer-5"></div>
            <div class="layer layer-6"></div>
            <div class="layer layer-7"></div>
            <div class="layer layer-8"></div>
        </div>
    </div>
    
    <!--====== PRELOADER PART START ======-->

    <!-- ============================================================== -->
    <!-- signup form  -->
    <!-- ============================================================== -->
    <form class="splash-container" action="<?= base_url('register/prosess') ?>" method="POST">
        <div class="card">
            <div class="card-header text-center">
                <a href="<?= base_url('') ?>">
                <img class="logo-img" src="<?= base_url('public') ?>/images/apple-touch-icon-1.png" alt="logo"></a></div>
            <div class="card-body">
                <?= $this->session->flashdata('pesan'); ?>
            <div class="card-body">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                        <img width="25" height="25" src="https://img.icons8.com/offices/25/graduation-cap.png" alt="graduation-cap"/></span></div>
                    <input type="text" name="name" placeholder="Username" class="form-control" required>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                        <img width="25" height="25" src="https://img.icons8.com/emoji/25/e-mail.png" alt="e-mail"/>
                    </span></div>
                    <input type="text" name="email" placeholder="E-mail" class="form-control" required>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                        <img width="25" height="25" src="https://img.icons8.com/external-nawicon-flat-nawicon/25/external-key-hotel-nawicon-flat-nawicon.png" alt="external-key-hotel-nawicon-flat-nawicon"/>
                    </span></div>
                    <input type="password" name="password" placeholder="Password" class="form-control" required>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                        <img width="25" height="25" src="https://img.icons8.com/external-nawicon-flat-nawicon/25/external-key-hotel-nawicon-flat-nawicon.png" alt="external-key-hotel-nawicon-flat-nawicon"/>
                    </span></div>
                    <input type="password" name="password2" placeholder="Confirm" class="form-control" required>
                </div>
                <div class="form-group pt-2">
                    <button type="submit" class="btn btn-block text-white" style="background-color: #004085;">Daftar</button>
                </div>
                
            </div>
            <div class="card-footer bg-white">
                <p>Sudah daftar? <a href="<?= base_url('login') ?>" class="text-secondary">Masuk disini.</a></p>
            </div>
        </div>
    </form>

    <!--====== jquery js ======-->
    <script src="<?= base_url('public') ?>/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="<?= base_url('public') ?>/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="<?= base_url('public') ?>/js/bootstrap.min.js"></script>
    
    <!--====== Slick js ======-->
    <script src="<?= base_url('public') ?>/js/slick.min.js"></script>
    
    <!--====== Magnific Popup js ======-->
    <script src="<?= base_url('public') ?>/js/jquery.magnific-popup.min.js"></script>
    
    <!--====== Counter Up js ======-->
    <script src="<?= base_url('public') ?>/js/waypoints.min.js"></script>
    <script src="<?= base_url('public') ?>/js/jquery.counterup.min.js"></script>
    
    <!--====== Nice Select js ======-->
    <script src="<?= base_url('public') ?>/js/jquery.nice-select.min.js"></script>
    
    <!--====== Nice Number js ======-->
    <script src="<?= base_url('public') ?>/js/jquery.nice-number.min.js"></script>
    
    <!--====== Count Down js ======-->
    <script src="<?= base_url('public') ?>/js/jquery.countdown.min.js"></script>
    
    <!--====== Validator js ======-->
    <script src="<?= base_url('public') ?>/js/validator.min.js"></script>
    
    <!--====== Ajax Contact js ======-->
    <script src="<?= base_url('public') ?>/js/ajax-contact.js"></script>
    
    <!--====== Main js ======-->
    <script src="<?= base_url('public') ?>/js/main.js"></script>
    
    <!--====== Map js ======-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDC3Ip9iVC0nIxC6V14CKLQ1HZNF_65qEQ"></script>
    <script src="<?= base_url('public') ?>/js/map-script.js"></script>
    <script src="<?= base_url('public') ?>/assets/vendor/datepicker/moment.js"></script>
    <script src="<?= base_url('public') ?>/assets/vendor/datepicker/tempusdominus-bootstrap-4.js"></script>
    <script src="<?= base_url('public') ?>/assets/vendor/datepicker/datepicker.js"></script>
</body>
</body>

 
</html>