<?php

if ($user) {
	$this->load->view($user);
}
