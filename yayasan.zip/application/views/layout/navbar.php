<!--====== HEADER PART START ======-->
    
    <header id="header-part">
       
        <div class="header-top d-none d-lg-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="header-contact text-lg-left text-center">
                            <ul>
                                <li><img src="<?= base_url('public') ?>/images/all-icon/map.png" alt="icon"><span>Bogor City 43, Cibinong</span></li>
                                <li><img src="<?= base_url('public') ?>/images/all-icon/email.png" alt="icon"><span>intiperubahanbangsa@gmail.com</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="header-opening-time text-lg-right text-center">
                            <p>Opening Hours : Senin Dan Sabtu - 8 Am to 5 Pm</p>
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- header top -->
        
        <div class="header-logo-support pt-30 pb-30">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <div class="logo">
                            <a href="<?= base_url('') ?>">
                                <img src="<?= base_url('public') ?>/images/awe1.png" alt="Logo">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8">
                        <div class="support-button float-right d-none d-md-block">
                            <div class="support float-left">
                                <div class="icon">
                                    <img src="<?= base_url('public') ?>/images/all-icon/support.png" alt="icon">
                                </div>
                                <div class="cont">
                                    <p>Need Help? call us free</p>
                                    <span>+62 813 8198 8665</span>
                                </div>
                            </div>
                            <div class="button float-left">
                                <a href="<?= base_url('register') ?>" class="main-btn">Join Now</a>
                            </div>
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- header logo support -->
        
        <div class="navigation">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 col-md-10 col-sm-9 col-8">
                        <nav class="navbar navbar-expand-lg">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto">
                                    <li class="nav-item">
                                        <a class="active" href="<?= base_url('') ?>">Home</a>
                                        <ul class="sub-menu">
                                            <li><a href="<?= base_url('') ?>">Kampus</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?= base_url('kampus') ?>">Suasana Kampus</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?= base_url('layanan') ?>">Layanan</a>
                                        <ul class="sub-menu">
                                            <li><a href="<?= base_url('') ?>">Courses</a></li>
                                            <li><a href="<?= base_url('') ?>">Course Singel</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?= base_url('about') ?>">Tentang Kami</a>
                                        <ul class="sub-menu">
                                            <li><a href="<?= base_url('about') ?>">About</a></li>
                                            <li><a href="<?= base_url('') ?>">Visi Dan Misi YPI</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?= base_url('program') ?>">Program</a>
                                        <ul class="sub-menu">
                                            <li><a href="<?= base_url('') ?>">teachers</a></li>
                                            <li><a href="<?= base_url('') ?>">teacher Singel</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?= base_url('akademik') ?>">Akademik</a>
                                        <ul class="sub-menu">
                                            <li><a href="<?= base_url('') ?>">PG TK YPI</a></li>
                                            <li><a href="<?= base_url('') ?>">SD YPI</a></li>
                                            <li><a href="<?= base_url('') ?>">SMP YPI</a></li>
                                            <li><a href="<?= base_url('') ?>">SMA YPI</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?= base_url('ppdb') ?>">PPDB</a>
                                        <ul class="sub-menu">
                                            <li><a href="s<?= base_url('') ?>"></a></li>
                                            <li><a href="<?= base_url('') ?>"></a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?= base_url('kontak') ?>">Kontak</a>
                                        <ul class="sub-menu">
                                            <li><a href="<?= base_url('lokasi') ?>">Lokasi</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav> <!-- nav -->
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-3 col-4">
                        <div class="right-icon text-right">
                            <ul>
                                <li><a href="#" id="search"><i class="fa fa-search"></i></a></li>
                            </ul>
                        </div> <!-- right icon -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div>
        
    </header>
    
    <!--====== HEADER PART ENDS ======-->