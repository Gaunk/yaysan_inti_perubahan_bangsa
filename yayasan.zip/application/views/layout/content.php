<?php

if ($home) {
	$this->load->view($home);
}
